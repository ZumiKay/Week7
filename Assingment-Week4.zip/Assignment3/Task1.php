<?php
interface A
{
    public function interfaceA();
}
interface B
{
    public function interfaceB();
}
class Multiple implements A, B
{

    function interfaceA()
    {
         echo "\n Hello";
    }
 

    function interfaceB()
    {
        echo "\n My";
    }
 
    public function insidemultiple()
    {
     echo "\n Friend";
    }
}
$test = new multiple();
$test->interfaceA();
$test->interfaceB();
$test->insidemultiple();










?>