<?php

const br='<br/>';

interface Element {
    public function getSales();
   
}
class ABA implements Element {
    public function getSales() {
        return array ( 'items 1 Price: 5 Q: 1 Total: 5',
        'items 3 Price: 5 Q: 1 Total: 4',
        'items 4 Price: 5 Q: 1 Total: 5',
        'items 6 Price: 5 Q: 1 Total: 10');
    }
  
}
class Wing implements Element {
    public function getSales() {
        return array( 'items 2 Price: 3 Q: 2 Total: 6',
        'items 7 Price: 15 Q: 1 Total: 15',
        'items 8 Price: 2 Q: 1 Total: 2');
    }
    public function oderSales() {
        return array(15,6,2);
    }
}
class PiPay implements Element {
    public function getSales(){
        return array( 'items 5 Price: 6 Q: 2 Total: 7');
    }
   

}
class orderbyTotal implements Element {
    public function getSales(){
        $arr = array('items 1 Price: 5 Q: 1 Total: 5'=>'5',
        'items 3 Price: 5 Q: 1 Total:4'=>'4',
        'items 4 Price: 5 Q: 1 Total: 5'=>'5',
        'items 6 Price: 5 Q: 1 Total: 10'=>'10',
        'items 2 Price: 3 Q: 2 Total: 6'=>'6',
        'items 7 Price: 15 Q: 1 Total: 15'=>'15',
        'items 8 Price: 2 Q: 1 Total: 2'=>'2',
        'items 2 Price: 3 Q: 2 Total: 6'=>'6',
        'items 7 Price: 15 Q: 1 Total: 15'=>'15',
        'items 8 Price: 2 Q: 1 Total: 2'=>'2',
        'items 5 Price: 6 Q: 2 Total: 7'=>'7'
    );
    arsort($arr);
    
    foreach($arr as $x=>$x_value)
        {
        echo $x.br;
        }
    }
}
function describe (Element $element)
{
    echo '<strong>'.get_class($element).br.'</strong>';
    if(is_array($element->getSales())){
        foreach($element->getSales() as $Sales){
            echo $Sales.br ;
        }
    }
}


$element = new ABA;
describe($element);
$element = new Wing;
describe($element);
$element = new PiPay;
describe($element);
echo '<strong>OrderByTotal:</strong>'.br;
$element = new orderbyTotal;
$element->getSales();








?>